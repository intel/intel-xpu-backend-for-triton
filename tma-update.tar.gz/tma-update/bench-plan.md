# TMA Descriptor Update — Benchmark Plan

Goal: prove (or disprove) the runtime win of **hoist + per-iteration
`tensormap.replace`** over the current **`tensormap_create`-per-iteration**, at
the **PTX level**, with **no compiler changes**. Build everything offline on
XE4; spend Blackwell (or Hopper) time only on assemble + time.

See [[tma-descriptor-update-project]], [[tma-update-hardware-constraint-and-tradeoff]],
[[tma-update-benchmark-strategy]] for context.

## Why PTX-level A/B (no new op needed to measure)

The optimized form needs an op (`tensormap_replace`) that doesn't exist yet.
Rather than build it before knowing it pays off, we hand-produce both PTX
variants and inject them via Triton's kernel-override hook. ptxas validates
both; everything outside the descriptor build is byte-identical, so the diff is
purely the descriptor-update strategy.

PTX is the right level:
- TTGIR can't express the optimized form (no `tensormap_replace` op).
- LLIR could (hand-written inline asm) but LLVM-O3 may reorder it.
- PTX is closest to metal; ptxas is the correctness gate.
- Bonus: the "persistent SMEM" problem that's thorny in MLIR allocation
  vanishes here — `.shared` is a static decl that already persists. The
  optimized variant is pure **instruction motion**: hoist the zero-fill + 15
  invariant `tensormap.replace.tile.*` + the initial `cp_fenceproxy` above the
  loop label; keep only `global_address` replace + cp_fenceproxy + acquire
  inside.

Fallback if ptxas regalloc fights the hand-edit: override at `llir` instead.

## The Override Mechanism (verified)

`compiler.py:270,345-347`: with `TRITON_KERNEL_OVERRIDE=1`, for each stage Triton
looks for a replacement file and, if present, parses it instead of running the
stage:

```python
fn_override_manager = get_override_manager(src.hash()) if enable_override else None
...
elif full_name := fn_override_manager.get_file(ir_filename):
    print(f"\nOverriding kernel with file {full_name}")
    next_module = parse(full_name, ext, context)
```

Layout (`cache.py:46-48,67-69`):
- Directory: `${TRITON_OVERRIDE_DIR}/${src.hash()}/`
  (default `~/.triton/override/`; `src.hash()` is the **source** hash, stable
  across triton-core changes — `compiler.py:261-262`).
- Filename: `${kernel_name}.${ext}`, e.g. `paged_kv_load_kernel.ptx`.
- When the `ptx` file is overridden, stages at/above ptx (ttir, ttgir, llir)
  still run normally; only the ptx module is swapped, then ptx→cubin (ptxas)
  proceeds. So we override **ptx** and let ptxas assemble on the GPU box.

Note `src.hash()` (override key) ≠ the full cache `hash` (which folds in backend
+ options + env). The harness prints the override path on hit
("Overriding kernel with file ...") — assert on that line so a silent miss
(stale hash, wrong filename) fails loudly instead of benchmarking the baseline
twice.

## Offline (XE4) vs Online (GPU) Split

| Phase | Where | What |
|---|---|---|
| Generate baseline PTX | **XE4 offline** | `paged_kv_load.py compile_for_target(stop_after="ptx")` → `.target sm_100a` PTX (confirmed working) |
| Produce optimized PTX | **XE4 offline** | `ptx_hoist.py` transforms baseline → hoisted variant |
| Textual validation | **XE4 offline** | structural asserts on the transformed PTX (counts, loop-body membership) |
| Harness | **XE4 offline** | dev/dry-run against captured PTX (no launch) |
| ptxas assemble + run + time | **GPU only** | inject both via override, CUDA-event timing, correctness gate |
| Occupancy / SMEM sweep | **GPU only** | full-kernel phase 2 |

`ptxas` is not installed on XE4, but we never need it offline — it runs on the
GPU box at inject time.

## Artifacts

1. **`gen_baseline.sh`** — wraps `run_blackwell.sh --arch <sm> --save-ir <dir>`
   extended through the `ptx` stage. Emits `<kernel>.ptx` + records `src.hash()`.
   Offline.

2. **`ptx_hoist.py`** — the transform. Input: baseline PTX. Output: optimized
   PTX. Steps:
   - Find the loop header label (`$L__BB0_1`) and back-edge (`bra $L__BB0_1`).
   - Identify the descriptor-build block inside the loop: the `st.shared` zero
     fill, the 16 `tensormap.replace.tile.*`, the `cp_fenceproxy`.
   - Classify each `tensormap.replace.tile.*` as invariant (operand is a
     loop-invariant reg / immediate) vs. variant (`global_address`, depends on
     the in-loop block-table load).
   - Emit: invariant replaces + zero-fill + initial cp_fenceproxy **before** the
     loop label; keep only `global_address` replace + cp_fenceproxy + acquire
     inside.
   - Scripted (not a manual diff) so it's reproducible and reviewable. For the
     very first smoke run a hand-checked diff is acceptable, but land the script.
   - SSA caveat: PTX virtual regs feeding the hoisted replaces must be defined
     before the loop. If a value is computed inside the loop but is actually
     invariant (e.g. `stride * elemsize`), the transform must also hoist its
     defining instruction. Start by asserting the invariant operands are
     already loop-invariant regs and bail loudly otherwise.

3. **`bench_ab.py`** — the harness. For variant ∈ {baseline, optimized}:
   - Place the PTX at `${TRITON_OVERRIDE_DIR}/${hash}/${kernel}.ptx`.
   - Run with `TRITON_KERNEL_OVERRIDE=1`, assert the "Overriding kernel" line
     appeared.
   - Verify output tensor matches a reference (torch) — **gate timing on this**.
   - Time with CUDA events: N warmup + M trials, report median + min/max.
   - Print baseline vs optimized + speedup.

4. **Kernels (two tiers):**
   - **Microbench** = existing `tma-update/paged_kv_load.py`. Single-buffer (not
     pipelined) → the hand-edit is trivial instruction motion and the signal is
     **pure descriptor-update cost**. Start here.
   - **Real** = unified-attention (pipelined). Ring-slot multi-buffered edit;
     this is where the SMEM/occupancy risk actually appears. Phase 2.

## Measurement Methodology

- **Trip-count sweep** (`NUM_KV_BLOCKS`): plot time vs. trips for both variants.
  - **slope = per-iteration descriptor cost** → baseline slope > optimized slope
    is the win.
  - **intercept gap = one-time preheader build cost** of the optimized variant.
  - This decomposes the exact tradeoff (saved per-iter work vs. fixed preheader
    cost) into two measured numbers.
- **Occupancy sweep** (phase 2, full kernel): vary pipeline stages / buffer
  count; watch whether the optimized variant's pinned SMEM erodes the win. This
  measures the *risk* from the cost analysis.
- **Correctness gate** before any timing — hand-edited PTX is exactly where a
  silent bug hides.
- CUDA events, warmup, N trials, median + spread.

## Phasing

1. **Offline, XE4 — validate the inject end-to-end.** Linchpin. Even with a
   *no-op* PTX "transform" (copy baseline → optimized unchanged), confirm
   `bench_ab.py` injects, sees the "Overriding kernel" line, and the kernel
   still verifies. Do this before any real transform — if override doesn't fire,
   nothing downstream matters. (Requires a GPU for the run; the *setup* and a
   dry compile are offline.)
2. **Offline, XE4 — build `ptx_hoist.py`** against the captured microbench PTX;
   validate structurally.
3. **GPU, minimal — microbench A/B + trip-count sweep** on Hopper (same
   mechanism as Blackwell, cheaper) for first signal; confirm on Blackwell.
4. **GPU — pipelined unified-attention** A/B + occupancy sweep. The real result.

## Open Decisions

1. ~~Baseline PTX source~~ — RESOLVED: generated offline on XE4.
2. **Dev target:** Hopper first (cheaper, identical mechanism) then confirm
   Blackwell — or Blackwell-only? (recommend Hopper-first)
3. **Scope:** microbench-first (recommend) vs straight at unified-attention.
4. **Transform form:** scripted `ptx_hoist.py` from day one (recommend) vs
   hand-diff for the first smoke run.

## Risks / Unknowns

- **ptxas may reschedule** the hand-hoisted PTX (it's an optimizing assembler) —
  the emitted SASS might not preserve our instruction motion. Mitigate: inspect
  SASS (`nvdisasm` / `cuobjdump`) on the GPU box to confirm the hoist survived;
  if ptxas re-sinks, that itself is a finding (and an argument the optimization
  must live higher, as a real op + scheduling barrier).
- **Single-buffer microbench may under-represent the win** — the real benefit
  interacts with pipelining. Microbench isolates per-iter descriptor cost but
  won't show the occupancy tradeoff; that's phase 4's job.
- **Override-hash brittleness** — any change to the kernel source changes
  `src.hash()` and silently disables the override. The "Overriding kernel" assert
  is the guard.
