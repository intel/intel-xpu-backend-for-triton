# Design Hypothesis: `tensormap_replace` + Descriptor Hoisting

Goal: when a `tt.make_tensor_descriptor` sits inside a loop and only its `base`
(global address) varies per iteration, stop emitting a full `tensormap_create`
every trip. Instead build the descriptor once (hoisted) and issue a cheap
per-field **update** in the loop.

This file is grounded in the real IR dumped by `tma-update/run_blackwell.sh
--save-ir`. See the companion [README.md](README.md) for how to regenerate it.

## The Core Insight

Standard LICM cannot move `tensormap_create` out of the loop: `base` is one of
its operands, so the whole op is loop-variant and stays put.

A `replace` op is what *makes the hoist legal*. It splits the single create into:

* an **invariant part** — every field except `base`, and
* a **variant part** — `base` only.

Once split, LICM has something it can actually move. The transform is therefore
two coupled pieces, not one:

1. **Legality analysis** — does every operand of the create *except* `base`
   hoist out of the loop?
2. **Split + hoist** — rewrite into a hoisted create (invariant fields) plus an
   in-loop `replace(base=...)`.

## Evidence From the Dump

`tma-update/paged_kv_load_kernel.ttgir` (compiled for `cuda:100`), loop body:

```mlir
scf.for %j = %c0_i32 to %c32_i32 step %c1_i32 : i32 {
  %physical_block_idx_2 = tt.load %physical_block_idx_1 : !tt.ptr<i32>   // in-loop runtime read
  %physical_block_idx_3 = arith.extsi %physical_block_idx_2 : i32 to i64
  %kv_base   = arith.muli %physical_block_idx_3, %stride_kv_0 : i64
  %kv_base_4 = tt.addptr %kv_cache_ptr, %kv_base : !tt.ptr<bf16>, i64      // ← LOOP-VARYING base

  %kv_desc   = ttg.global_scratch_alloc {alignment = 128, nbytes = 128} : !tt.ptr<i8>
  %kv_desc_5 = arith.muli %stride_kv_1, %c2_i64 : i64                       // stride * elemsize (invariant)
  ttng.tensormap_create %kv_desc, %kv_base_4,
      [%c64_i32, %c16_i32],        // box_dim        ← invariant constants
      [%c128_i32, %c16_i32],       // global_dim     ← invariant constants
      [%kv_desc_5],                // global_stride  ← invariant (stride_kv_1 is a kernel arg)
      [%c1_i32, %c1_i32]           // element_stride ← invariant constants
      {elem_type = 10, fill_mode = 0, interleave_layout = 0, swizzle_mode = 3}
  ttng.tensormap_fenceproxy_acquire %kv_desc
  %kv_desc_6 = ttng.reinterpret_tensor_descriptor %kv_desc : !tt.ptr<i8> to !tt.tensordesc<16x128xbf16, #shared>

  %tile   = ttg.local_alloc : () -> !ttg.memdesc<16x128xbf16, #shared, #smem, mutable>
  %tile_7 = ttg.local_alloc : () -> !ttg.memdesc<1xi64, #shared1, #smem, mutable>
  ttng.init_barrier %tile_7, 1
  ttng.barrier_expect %tile_7, 4096, %true
  ttng.async_tma_copy_global_to_local %kv_desc_6[%c0_i32, %c0_i32] %tile, %tile_7, %true
  ttng.wait_barrier %tile_7, %c0_i32
  ttng.inval_barrier %tile_7
  ...
}
```

Operand classification:

| Create operand | Value in dump | Loop-varying? |
|---|---|---|
| `global_address` | `%kv_base_4` (from in-loop `tt.load`) | **YES** |
| `box_dim` | `[%c64_i32, %c16_i32]` | no (constants) |
| `global_dim` | `[%c128_i32, %c16_i32]` | no (constants) |
| `global_stride` | `[%kv_desc_5 = stride_kv_1 * 2]` | no (kernel arg × const) |
| `element_stride` | `[%c1_i32, %c1_i32]` | no (constants) |
| `elem_type / fill / interleave / swizzle` | attrs | no (compile-time) |

Exactly one operand varies. → legality analysis passes.

Note: this dump is **single-buffered** (`nbytes = 128`, no pipeline counter
iter-arg) because the loop's `descriptor_load` feeds a `store`, not a dot, so
it isn't pipelined. That makes the simplest in-place transform valid here. The
pipelined case is handled separately below.

## Proposed Op

A side-effecting per-field update on the descriptor buffer, at the TTNG level:

```mlir
ttng.tensormap_replace_global_address %desc_ptr, %new_addr
    : (!tt.ptr<i8>, !tt.ptr<bf16>) -> ()
```

* Memory effect: `MemWrite<GlobalMemory>` (same as `tensormap_create`).
* Generalizes to other fields (`replace_global_dim[N]`, `replace_global_stride[N]`,
  ...) keyed by an ordinal, but `global_address` is the case unified-attention
  needs.

### What already exists vs. what's missing

**No `tensormap_replace` / `tensormap_update` op exists at the IR level.** The
only TTNG tensormap ops today are `TTNG_TensormapCreateOp`
([TritonNvidiaGPUOps.td:1064](../include/triton/Dialect/TritonNvidiaGPU/IR/TritonNvidiaGPUOps.td#L1064))
and `TTNG_TensormapFenceproxyAcquireOp`
([:1102](../include/triton/Dialect/TritonNvidiaGPU/IR/TritonNvidiaGPUOps.td#L1102)).
There is nothing a transform or the pipeliner can emit to update a descriptor
in place — that op is what this proposal adds.

**The PTX primitive and its emitter already exist, but only privately.**
[TMAToLLVM.cpp:46-182](../third_party/nvidia/lib/TritonNVIDIAGPUToLLVM/TMAToLLVM.cpp#L46-L182)
defines C++ helpers (`tensormap_replace_global_address`,
`tensormap_replace_box_dim`, `tensormap_replace_global_dim`, ...) that each emit
a single `tensormap.replace.tile.<field>` PTX instruction. But they are only
called *inside* `TensormapCreateOpConversion` — the create lowers to "zero-fill
+ replace all 16 fields" ([TMAToLLVM.cpp:243-297](../third_party/nvidia/lib/TritonNVIDIAGPUToLLVM/TMAToLLVM.cpp#L243-L297)).
None of them is reachable from a standalone op.

So the new op's lowering is nearly free: `TensormapReplaceGlobalAddressOp`'s
`matchAndRewrite` is essentially lines 263-264 of the existing create
conversion (`tensormap_replace_global_address(...)`) plus the `cp_fenceproxy`
(SMEM→global), lifted into their own pattern, followed by the existing
`fenceproxy_acquire`. The hard parts are the legality analysis and the
multi-buffer/pipeliner integration — not the lowering.

## Transformed IR — Single-Buffer (matches this dump)

Because `tensormap.replace` only edits SMEM (see Hardware Constraint below),
the *canonical* descriptor lives in a **persistent SMEM staging buffer** built
once; each iteration edits the one field there and re-publishes SMEM→global so
the TMA engine sees it. The `replace_global_address` op below encapsulates the
SMEM edit + the `cp_fenceproxy` publish; `acquire` stays separate.

```mlir
//  ---- preheader (hoisted, built ONCE) ----
%kv_smem   = <persistent 128 B SMEM staging buffer>           // lives across the loop
%kv_desc   = ttg.global_scratch_alloc {alignment = 128, nbytes = 128} : !tt.ptr<i8>
%kv_desc_5 = arith.muli %stride_kv_1, %c2_i64 : i64
// Full build into SMEM + publish to global. global_address is a placeholder
// (%kv_cache_ptr) — overwritten by the first in-loop replace before any copy.
ttng.tensormap_create %kv_desc, %kv_cache_ptr,
    [%c64_i32, %c16_i32], [%c128_i32, %c16_i32], [%kv_desc_5], [%c1_i32, %c1_i32]
    {elem_type = 10, fill_mode = 0, interleave_layout = 0, swizzle_mode = 3}
%kv_desc_6 = ttng.reinterpret_tensor_descriptor %kv_desc : !tt.ptr<i8> to !tt.tensordesc<16x128xbf16, #shared>

scf.for %j = %c0_i32 to %c32_i32 step %c1_i32 : i32 {
  %physical_block_idx_2 = tt.load ...
  %kv_base   = arith.muli %physical_block_idx_3, %stride_kv_0 : i64
  %kv_base_4 = tt.addptr %kv_cache_ptr, %kv_base : !tt.ptr<bf16>, i64

  //  ---- the ONLY per-iteration descriptor work ----
  // edits global_address in SMEM staging, then cp_fenceproxy SMEM->global:
  ttng.tensormap_replace_global_address %kv_desc, %kv_base_4 : (!tt.ptr<i8>, !tt.ptr<bf16>) -> ()
  ttng.tensormap_fenceproxy_acquire %kv_desc

  ... async_tma_copy_global_to_local %kv_desc_6[%c0_i32, %c0_i32] ... ; wait_barrier ...
}
```

Note: the SMEM staging buffer (`%kv_smem`) must persist across iterations as the
source of truth — `cp_fenceproxy` copies the full 128 bytes, so editing in fresh
transient SMEM each iteration would require re-filling all 16 fields (i.e. just
`create` again). Modeling that persistent buffer is the main structural cost —
see Cost Delta below.

## Hardware Constraint: There Is No In-Place Global Update

The intuitive idea — "keep the descriptor in global memory and just poke the
address field each iteration" — is **not possible**, for three independent
reasons:

1. **No `.global` form of `tensormap.replace`.** The PTX ISA only defines
   `tensormap.replace.tile.<field>.shared::cta` — every emitter in
   [TMAToLLVM.cpp:58-62,97](../third_party/nvidia/lib/TritonNVIDIAGPUToLLVM/TMAToLLVM.cpp#L58)
   hardcodes `shared::cta`. The only field-editing primitive that exists
   requires the descriptor be in **SMEM**.
2. **The descriptor is opaque.** A `CUtensorMap` is an undocumented 128-byte
   blob; you cannot `st.global` a known byte offset for `global_address`.
   `tensormap.replace` is the only thing that knows the layout.
3. **The TMA proxy caches descriptors.** The engine reads descriptors through a
   separate memory proxy that must be coherently re-acquired
   (`fence.proxy.tensormap::generic.acquire`,
   [TMAToLLVM.cpp:204-205](../third_party/nvidia/lib/TritonNVIDIAGPUToLLVM/TMAToLLVM.cpp#L204))
   after *any* modification. NVIDIA's supported publish path is `cp_fenceproxy`
   (SMEM→global with release), which is why the edit must originate in SMEM.

**Consequence:** every update path — `create` or `replace` — must (a) edit in
SMEM, (b) publish SMEM→global via `cp_fenceproxy`, (c) `fenceproxy_acquire`.
The publish + acquire round-trip is an **irreducible per-iteration floor**.
`replace` can only remove the redundant *build* work (zero-fill + 15 invariant
fields), not the floor.

The host-side path (`cuTensorMapEncodeTiled`,
[driver.c:619](../third_party/nvidia/backend/driver.c#L619)) builds descriptors
on the CPU with zero in-kernel cost, but cannot express this case: `base`
depends on `block_tables`, known only at runtime inside the kernel.

## Cost Delta

Two viable points in the design space. Both must route through SMEM and both
pay the publish+acquire floor every iteration; they differ in *build* work and
*SMEM lifetime*.

### Per-iteration cost

| Work item | Threads | #1 `create`/iter (today) | #2 hoisted + `replace`/iter |
|---|---|---|---|
| `zero_fill_tma` (~32 SMEM stores + syncwarp) | first warp | every iter | **moved to preheader** (once) |
| `replace_global_address` (SMEM write) | thread 0 | 1 | 1 |
| 15× other `replace_*` (box/global dim, stride, elemtype, swizzle…) | thread 0, serialized | every iter | **moved to preheader** (once) |
| `cp_fenceproxy` (128 B SMEM→global + release) | first warp | every iter | every iter |
| `fenceproxy_acquire` (+commit/wait) | first warp | every iter | every iter |

The 16 replaces are **serialized on thread 0** ([line 65](../third_party/nvidia/lib/TritonNVIDIAGPUToLLVM/TMAToLLVM.cpp#L65)
predicates on `threadId == 0`) and gate the `cp_fenceproxy` on the critical
path — so the 15 redundant ones are real latency, not noise.

### One-time (preheader) cost

| | #1 `create` | #2 hoisted + `replace` |
|---|---|---|
| Build full descriptor in SMEM (zero_fill + 16 replaces) | none | once |
| `cp_fenceproxy` + initial `acquire` | none | once |

### Resource / structural cost

| | #1 `create` | #2 hoisted + `replace` |
|---|---|---|
| SMEM held across loop | ~0 (transient scratch, reused) | **128 B × #descriptors × #stages, pinned** |
| Allocation model | existing per-op scratch | **new: persistent SMEM lifetime** |
| Pipeliner interaction | works today | replace must target current ring slot |

### What #2 saves vs. what stays

- **Saves/iter:** 1× `zero_fill_tma` + 15× serialized single-thread `replace_*`
  writes (the ones gating `cp_fenceproxy`).
- **Irreducible floor (both pay/iter):** 1× `replace_global_address`,
  1× `cp_fenceproxy`, 1× `fenceproxy_acquire`.
- **Costs extra:** pins ~128 B SMEM per descriptor for the loop (occupancy
  risk), one-time preheader build, new persistent-SMEM allocation handling.

**One-line takeaway:** #2 trades **persistent SMEM** for deleting the
per-iteration **zero-fill + 15 redundant serialized field writes**. The
expensive `cp_fenceproxy` + `acquire` is unchanged, so the win is bounded by how
much the build vs. the fence dominates — and net positive only if the pinned
SMEM doesn't cost occupancy. This is the experiment the POC must measure on the
real unified-attention kernel.

## Correctness Constraints

1. **Re-acquire every iteration.** `fenceproxy_acquire` (and the preceding
   `cp_fenceproxy`) cannot be hoisted — the TMA proxy must observe the modified
   descriptor before the async copy reads it. Unchanged from today.

2. **Placeholder base in the hoisted create is dead.** The first in-loop
   replace overwrites `global_address` before any `async_tma_copy` reads it, so
   the value passed to the hoisted create (`%kv_cache_ptr` here, or poison) is
   irrelevant to correctness.

3. **Multi-buffer hazard under pipelining (the real unified-attention case).**
   This dump is single-buffered, so in-place reuse is safe: `wait_barrier`
   serializes the consumer before the next iteration's replace. But when the
   descriptor feeds a dot, the loop **gets pipelined**, multiple async copies
   are in flight, and an in-place update to one descriptor would clobber a
   descriptor a prior copy is still reading. There the replace must target a
   **rotating ring slot** — exactly the `numStages × TMA_SIZE_BYTES` buffer +
   modulo counter the pipeliner already builds in
   [lowerTMADescriptors](../lib/Dialect/TritonGPU/Transforms/Pipeliner/PipeliningUtility.cpp#L673-L709).
   The optimization there: prologue builds invariant fields into **every** slot
   once; the loop does **1 replace into the current slot** — instead of a full
   `createTMADesc` per slot per iteration. The legality analysis is identical;
   only the destination buffer differs.

## Where the Transform Runs

A LICM-style rewrite on `tt.make_tensor_descriptor` (or on `tensormap_create`),
**before** the pipeliner / `add_tma_lowering`:

1. For each descriptor-producing op inside an `scf.for`:
2. Check legality: every operand except `base` is loop-invariant
   (`forOp.isDefinedOutsideOfLoop`, or hoistable arith).
3. If legal, split:
   * hoist a create with the invariant fields (+ placeholder base) to the preheader,
   * replace the in-loop op with `tensormap_replace_global_address(desc, base)`.
4. Leave `fenceproxy_acquire` in the loop.

Generalization: if some dim `N` is the only loop-varying field instead of
`base`, hoist the create and emit `replace_global_dim[N]` / `replace_global_stride[N]`.
`base` is just the common case (and the one unified-attention needs).

The language API (`tl.make_tensor_descriptor`) is unchanged — existing kernels
benefit automatically.

## Open Questions

* **Generation site:** synthesize during `add_tma_lowering` (Nvidia-specific,
  least disruptive) vs. a target-independent TTGIR pass that the pipeliner then
  multi-buffers. The pipelined case argues for integrating with
  `lowerTMADescriptors` rather than a standalone pass.
* **Intel/AMD/pre-Hopper:** these rewrite descriptors to tensor-of-pointers, so
  a `replace` becomes plain pointer arith on the cached tuple — needs a lowering
  in `RewriteTensorDescriptorToPointer` or the op is gated Nvidia-only.
* **Multiple varying fields:** if both `base` and a `global_dim` vary (e.g.
  ragged sequence lengths), emit multiple replaces; still cheaper than a full
  create once 2+ fields are shared.
* **`cp_fenceproxy` cost:** the SMEM→global copy + acquire is the residual
  per-iteration cost. Measure whether it dominates; if so, a lighter-weight
  in-place global descriptor edit (no SMEM staging) may be worth exploring.
