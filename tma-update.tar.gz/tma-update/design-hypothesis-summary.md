# TMA Descriptor Update — Summary

## Problem

When `tl.make_tensor_descriptor` sits inside a loop and only its `base` address
varies per iteration, Hopper+ emits a full `ttng.tensormap_create` (16 fields +
fenceproxy) **every iteration** — even though 15 of 16 fields are loop-invariant.
This shows up in the vLLM unified-attention paged-KV loop, where `base` depends
on a per-iteration `block_tables` load and so cannot be hoisted by normal LICM.

## Evidence (real TTGIR, `cuda:100`)

```mlir
scf.for %j = ... {
  %kv_base_4 = tt.addptr %kv_cache_ptr, %kv_base          // ← only this varies
  ttng.tensormap_create %kv_desc, %kv_base_4,
      [%c64,%c16], [%c128,%c16], [%stride], [%c1,%c1]      // all loop-invariant
      {elem_type=10, swizzle_mode=3, ...}
  ttng.tensormap_fenceproxy_acquire %kv_desc
  ... async_tma_copy ...
}
```

## Key Insight

Standard LICM can't move `tensormap_create` — `base` is one of its operands, so
the whole op is loop-variant. A **`replace` op splits the create** into an
invariant part (all fields but `base`) and a variant part (`base` only), which
is what *makes the hoist legal*.

## Proposal

Add an IR op `ttng.tensormap_replace_global_address(desc, new_addr)`, then a
LICM-style transform:

1. **Legality:** for a descriptor build in a loop, check every operand except
   `base` is loop-invariant.
2. **Split + hoist:** emit the full create once in the preheader (placeholder
   base — overwritten before first use); leave only `replace(base)` +
   `fenceproxy_acquire` in the loop.

```mlir
// preheader
ttng.tensormap_create %kv_desc, %placeholder, [...invariant...] {...}
scf.for %j = ... {
  ttng.tensormap_replace_global_address %kv_desc, %kv_base_4   // 1 field, not 16
  ttng.tensormap_fenceproxy_acquire %kv_desc
  ... async_tma_copy ...
}
```

## What exists vs. what's missing

- **Missing:** any IR-level replace/update op. Only `tensormap_create` +
  `tensormap_fenceproxy_acquire` exist today.
- **Already exists:** the PTX primitive `tensormap.replace.tile.*` and private
  C++ emitters in `TMAToLLVM.cpp` — but only as the *implementation* of create.
  The new op's lowering reuses them almost verbatim.

## Hardware constraint: no in-place global update

You cannot "keep the descriptor in global and poke the address": (1) PTX only
has `tensormap.replace.tile.*.shared::cta` — no `.global` form; (2) the
descriptor is an opaque 128-byte blob, so no raw `st.global` to a known offset;
(3) the TMA proxy caches descriptors and must be re-acquired after any change.
So **every** update routes through SMEM → `cp_fenceproxy` (SMEM→global) →
`acquire`. That publish+acquire round-trip is an irreducible per-iteration floor.

## Cost (per iteration)

| Work | #1 `create` (today) | #2 hoisted + `replace` |
|---|---|---|
| `zero_fill` (~32 SMEM stores + syncwarp) | every iter | **hoisted (once)** |
| 15× redundant `replace_*` (serialized on thread 0) | every iter | **hoisted (once)** |
| `replace_global_address` | 1× | 1× |
| `cp_fenceproxy` (SMEM→global) | ✓ | ✓ (floor) |
| `fenceproxy_acquire` | ✓ | ✓ (floor) |
| **SMEM held across loop** | ~0 (transient) | **128 B × descs × stages (pinned)** |

**Trade:** #2 spends persistent SMEM to delete the per-iteration zero-fill + 15
serialized field writes. The expensive `cp_fenceproxy` + `acquire` is unchanged,
so the win is bounded and net positive only if the pinned SMEM doesn't cost
occupancy — that's what the POC must measure.

## Constraints

1. `fenceproxy_acquire` + `cp_fenceproxy` stay in-loop — irreducible floor.
2. The SMEM staging buffer must **persist** across iterations as source of truth
   (`cp_fenceproxy` copies all 128 B; transient SMEM would force a full rebuild).
3. Placeholder base in the hoisted create is dead (overwritten before use).
4. **Pipelined loops** (the real unified-attention case): the descriptor is
   multi-buffered, so the replace must write the **current ring slot**, not a
   single buffer — reuse the pipeliner's existing `numStages × TMA_SIZE_BYTES`
   buffer + counter. Prologue fills invariant fields into every slot once; the
   loop does 1 replace into the live slot.

Full version: [design-hypothesis.md](design-hypothesis.md).
